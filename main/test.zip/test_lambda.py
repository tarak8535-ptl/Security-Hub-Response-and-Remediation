def test(event, context):
    print("Lambda test")